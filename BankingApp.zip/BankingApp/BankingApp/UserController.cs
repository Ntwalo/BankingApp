﻿using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Web.Mvc;

public class UserController : Controller
{
    private BankingContext db = new BankingContext();

    public ActionResult Register()
    {
        return View();
    }

    [HttpPost]
    public ActionResult Register(User user)
    {
        if (ModelState.IsValid)
        {
            db.Users.Add(user);
            db.SaveChanges();
            return RedirectToAction("Login");
        }
        return View(user);
    }

    public ActionResult Login()
    {
        return View();
    }

    [HttpPost]
    public ActionResult Login(string email, string password)
    {
        var user = db.Users.FirstOrDefault(u => u.Email == email && u.Password == password);
        if (user != null)
        {
            Session["UserId"] = user.Id;
            return RedirectToAction("Index", "Account");
        }
        ViewBag.Message = "Invalid credentials.";
        return View();
    }

    public ActionResult Logout()
    {
        Session.Clear();
        return RedirectToAction("Login");
    }
}
