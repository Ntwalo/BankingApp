﻿public class Account
{
    public int AccountNumber { get; set; }
    public int UserId { get; set; }
    public decimal Balance { get; set; }
}
