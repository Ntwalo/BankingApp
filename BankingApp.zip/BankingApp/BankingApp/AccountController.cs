﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Web.Mvc;

public class AccountController : Controller
{
    private BankingContext db = new BankingContext();

    [Authorize]
    public ActionResult Index()
    {
        int userId = (int)Session["UserId"];
        var accounts = db.Accounts.Where(a => a.UserId == userId).ToList();
        return View(accounts);
    }

    [Authorize]
    public ActionResult Create()
    {
        return View();
    }

    [HttpPost]
    [Authorize]
    public ActionResult Create(Account account)
    {
        if (ModelState.IsValid)
        {
            account.UserId = (int)Session["UserId"];
            db.Accounts.Add(account);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        return View(account);
    }

    [Authorize]
    public ActionResult Deposit(int id)
    {
        var account = db.Accounts.Find(id);
        return View(account);
    }

    [HttpPost]
    [Authorize]
    public ActionResult Deposit(int id, decimal amount)
    {
        var account = db.Accounts.Find(id);
        if (account != null && amount > 0)
        {
            account.Balance += amount;
            db.Transactions.Add(new Transaction
            {
                AccountNumber = account.AccountNumber,
                Amount = amount,
                Date = DateTime.Now
            });
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        return View(account);
    }

    [Authorize]
    public ActionResult Withdraw(int id)
    {
        var account = db.Accounts.Find(id);
        return View(account);
    }

    [HttpPost]
    [Authorize]
    public ActionResult Withdraw(int id, decimal amount)
    {
        var account = db.Accounts.Find(id);
        if (account != null && amount > 0 && account.Balance >= amount)
        {
            account.Balance -= amount;
            db.Transactions.Add(new Transaction
            {
                AccountNumber = account.AccountNumber,
                Amount = -amount,
                Date = DateTime.Now
            });
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        return View(account);
    }
}
